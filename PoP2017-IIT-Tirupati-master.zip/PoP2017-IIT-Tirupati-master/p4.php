﻿<!DOCTYPE html>
<html>
<head>
<title>Login Page</title>
<link rel="stylesheet" type = "text/css" href ="new.css">
</head>
<body >

<div id="frrm">
<form action ="process2.php" method ="POST">
<p>
<label>ENTER COMPANY NUMBER:</label>
<input type ="text" id ="xyz"  name ="xyz"/>
</p>

<p>
<input type ="submit" id ="btn1"  value ="Search"/>
</p>
</form>
</div>
<p>
1-AMAZON</br>
2-AB INBEV</br>
3-ADOBE</br>
4-AMAZON (INDIA)</br>
5-AMERICAN EXPRESS</br>
6-AXIS BANK</br>
7-BAYCURRENT (JAPAN)</br>
8-CAPITAL ONE</br>
9-CITICORP</br>
10-EATON TECHNOLOGIES</br>
11-EDGEVERVE SYSTEMS LTD</br>
12-EXL SERVICES INDIA PVT LTD</br>
13-GENERAL ELECTRIC (GE)</br>
14-GLOBOCON TECHNOLOGY</br>
15-GOLDMAN SACHS (GS)</br>
16-HINDUSTAN UNILEVER</br>
17-IBM</br>
18-INFOSYS</br>
19-ITC</br>
20-JSW</br>
21-J P MORGAN</br>
22-MICROSOFT</br>
23-MONDELEZ INTERNATIONAL</br>
24-NOMURA</br>
25-P & G</br>
26-QUALCOMM</br>
27-SALESFORCE</br>
28-SAMSUNG</br>
29-SCHLUMBERGER</br>
30-SYSTEMANTICS INDIA PVT LTD</br>
31-TATA STEEL</br>
32-TEXAS INSTRUMENTS</br>
33-TITAN</br>
34-VISA</br>
35-VMWARE</br>
36-WIPRO</br>
37-WRIG NANOSYSTEMS
</p>
</body>


</html>