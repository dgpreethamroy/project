# PoP - Paradigms of Programming [Adventures in Programming Languages]
This is the core directory structure (assignments, projects, feedback and more) of PoP course at IIT Tirupati 

Everybody, clone this project structure in your accounts and update! 
Don't wait till you finish entire thing. Upload as-is because Github tells us what did you do, when did you do!
